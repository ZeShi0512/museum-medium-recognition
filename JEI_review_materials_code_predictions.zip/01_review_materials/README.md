# Reproducing the museum medium recognition analysis

This package accompanies the study of 17 shared material and technique labels in three museums using frozen ConvNeXt and DINOv2 representations. It contains the recorded splits, support draws, classifier selections, per-image predictions and analysis inputs. Source images and pretrained encoder weights are obtained from their original providers. No human-subject data or new expert annotations are included.

## Quick verification

With Python and NumPy available, run:

```bash
python code/verify_results.py
```

The command performs no network requests and fits no model. It recomputes balanced accuracy for 1,140 stored prediction sets, checks 240 support-only C selections against 720 recorded cross-validation scores, checks nested support assignments, and recomputes the 36 paired bootstrap intervals for validated EasyAdapt. A successful run prints `"status": "PASS"` and writes `results/verification_report.json`. This verifies the archived numerical results; it does not independently verify every source image or the visual judgments.

## Refit classifiers from saved features

The separately supplied author backup folder `02_private_feature_cache` contains the four archived frozen-feature arrays and six original source heads. It is excluded from the nested review-only ZIP. A reviewer who receives that cache can rerun head fitting with Python, NumPy and scikit-learn 1.8.0:

```bash
python code/rerun_heads.py --cache-dir ../02_private_feature_cache --output-dir ../refit_output --encoder convnext --fold 0 --seed 0 --budget 5
```

The command refits four fixed-C heads, four selected-C heads and one target prototype. Add `--reselect-c` to repeat five-fold target-support validation instead of using the archived choices. Omit the encoder, fold, seed and budget filters to reproduce the full set. Source-only predictions use the archived C = 1 heads; the script does not retune them. All decisions use only development support labels. Comparison with archived confirmation predictions occurs after fitting and prediction.

The default output directory must be supplied explicitly. Use a new directory: matching output files are overwritten. Commands do not install dependencies or modify the operating system configuration. On Windows, extract the package to a D-drive project directory and use that directory for outputs.

## Re-extract image features

The exact public dataset revision, small-archive URL and SHA256 are in `protocols/data_source.json`. Model weight URLs and hashes are in `protocols/encoder_assets.json`. The original runtime was Python 3.12.14, PyTorch 2.6.0+cpu, torchvision 0.21.0+cpu, NumPy 2.3.5 and scikit-learn 1.8.0. DINOv2 source commit is `7764ea0f912e53c92e82eb78a2a1631e92725fc8`. The supplied encoder code uses CPU inference, batch size 16, deterministic algorithms, the 224-pixel centre crop and L2 feature normalization.

After separately obtaining the upstream archive and model assets, use:

```bash
python code/extract_features.py --archive PATH_TO_SMALL_ZIP --weights PATH_TO_CONVNEXT_WEIGHTS --encoder convnext --output-dir PATH_TO_NEW_FEATURE_CACHE
python code/extract_features.py --archive PATH_TO_SMALL_ZIP --weights PATH_TO_DINOV2_WEIGHTS --encoder dinov2 --dinov2-code-dir PATH_TO_PINNED_DINOV2_SOURCE --output-dir PATH_TO_NEW_FEATURE_CACHE
```

These are user-supplied paths, not literal filenames. The extractor checks image-archive and weight SHA256 values. It does not download assets. Verify the separately obtained DINOv2 source archive against `encoder_assets.json` before supplying its extracted directory. Copy the six source-head files from the author cache into the new feature directory, or reconstruct the original source heads from source-support rows using the documented C = 1 logistic regression. Re-extracted features can vary slightly across numerical libraries or hardware; use the archived features to isolate classifier reproduction from encoder implementation differences.

## File map

|Location|Contents|
|---|---|
|`data/development_manifest.csv`|2,540 development images in exact feature-array order, museum, medium, family key and training roles|
|`data/confirmation_manifest.csv`|1,008 confirmation images in exact feature-array order, with recorded input hashes|
|`data/support_draws.json`|90 nested support draws: three museums, ten seeds, one/three/five images per class|
|`data/selected_C.json`, `data/CV_scores.json`|240 choices and 720 candidate scores; ties select the smaller C|
|`data/excluded_confirmation_images.json`|13-image composition exclusion and 54-image all-candidate exclusion|
|`data/visual_screen_candidates.json`|All 80 screened pairs and the assistant's low-resolution visual classifications|
|`results/fixed_predictions.npz`|720 fixed-C prediction arrays|
|`results/validated_predictions.npz`|240 selected-C logistic arrays and 180 prototype arrays|
|`results/source_predictions.npz`|Six original source-only confirmation prediction arrays|
|`results/manuscript_tables`|Source tables used by the second manuscript draft|
|`protocols`|Dataset/model provenance, original settings and appended-analysis settings|
|`historical_code`|Preserved original stage scripts; these retain their historical directory assumptions|

NPZ array keys follow `head_ENCODER_FOLD_SEED_PER_CLASS_BUDGET_METHOD`. Fold order is the order in `data/museums.json`: LACMA, Met, Cleveland. A prediction array follows the confirmation manifest filtered to that museum, without reordering. Integer class indices follow `data/classes.json`. All manifest indices and support indices are zero-based. Summary values are fractions unless a column ends in `_pp` or is printed as a percentage in the manuscript.

`source_role` describes an image's role when its museum supplies source data. Only rows with `source_role = support` enter source fitting. `target_support_pool = True` marks membership of the fixed ten-per-class target-support pool. This pool is reconstructed from the union of all originally archived support draws, not reselected from recognition outcomes. Only the original first ten support seeds used by the manuscript are included here. Source roles and target roles apply in different held-out-museum folds; a target support image is never source training data in its own fold. The original MAMe split (`official_subset`) is retained as metadata; this study uses its own museum-held-out assignments.

## Interpretation

The fixed-C budget curves and selected-C comparison are separate analyses. Additional methods and budget analyses used a confirmation pool that had already been exposed. Support-only validation does not create a new blind test. Bootstrap intervals condition on the recorded source data, encoders and support draws; overlapping draws are not independent test sets. Visual-screen categories are not official determinations of work or impression identity. Both original and exclusion results are retained.

## Rights and availability

MAMe is provided for non-commercial research purposes only. This package does not redistribute source images or pretrained weights. Metadata, predictions and cached derived features do not replace the upstream provider's terms. No blanket licence is granted over third-party content. The archive is prepared for author review and submission planning; no public code repository or DOI has been created.

## Extended claim audit

Run `python code/recompute_joint_intervals.py` to regenerate all 72 original/excluded paired comparisons of Append, Domain-balanced and EasyAdapt against the two local controls. `results/all_joint_source_reuse_intervals.csv` provides the complete numerical table underlying manuscript Table 4. Existing EasyAdapt intervals are cross-checked against the original archive.

A separate cache-based check refitted all six source-only classifiers and exactly matched saved predictions; the backup heads gave the same predictions. `python code/rerun_sources.py --cache-dir PATH --output-dir PATH` exposes that reproduction route. This archive does not contain the derived-feature cache or the six backup heads. Obtain features from the source images with the supplied extraction wrapper, or use the separate author cache, before running refits. This audit did not repeat feature extraction or refit every adapted head. Detailed scope is recorded in results/verification_coverage.json.

The historical timestamped protocol does not establish preregistration of the 85-label weighted baseline. The manuscript treats these comparisons as descriptive and makes no such priority claim.

The extended cache-based refit now also covers 54 adapted/local classifier and prototype results: both encoders, all three museum folds, support seed 0, budget 5, fixed and selected-C modes, with C validation repeated. Every saved prediction matched. This expands the original nine-result smoke test without claiming that the remaining nine support seeds were refitted.
