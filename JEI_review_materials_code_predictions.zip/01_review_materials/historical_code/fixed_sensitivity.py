import pathlib,json,csv,zipfile
import numpy as np
R=pathlib.Path(__file__).resolve().parent;W=R.parent/'draft_work';Q=W/'museum_confirmation_v01';B=W/'museum_data_gate_v01';D=W/'museum_budget_v01';pairs=json.loads((R/'candidates.json').read_text());allrows=list(csv.DictReader((Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv').open(encoding='utf-8-sig')));classes=json.loads((B/'grouping_correction.json').read_text())['eligible_classes'];museums=sorted({r['museum'] for r in allrows});preds=np.load(D/'all_predictions.npz')
composition={1,4,34,36,37,40,41,42,43,44,61};unclear={3,5,10,11,12,13,15,27,28,29,31,38,39,46,47,48,49,50,51,54,55,57,58,59,60,62,63,64,66,67,69,70,72,73,74,76,77,78,79,80}
for p in pairs:
 n=int(p['review_id'][1:]);p['visual_review']='same_composition_or_reproduction' if n in composition else 'related_design_or_series_identity_unresolved' if n in unclear else 'visually_distinct_composition_or_object';p['reviewer']='assistant visual review, 256px archive, contact sheets';p['identity_limit']='No official work/edition identity adjudication; visual category is not a confirmed leakage label.'
(R/'reviewed_candidates.json').write_text(json.dumps(pairs,indent=2));exclusions={}
for policy in ['same_composition','all_screened_candidates']:
 excluded=set()
 for p in pairs:
  if policy=='same_composition' and p['visual_review']!='same_composition_or_reproduction':continue
  for side in ['a','b']:
   if p[side+'_role']=='confirmation':excluded.add(p[side+'_file'])
 exclusions[policy]=sorted(excluded)
(R/'excluded_confirmation_images.json').write_text(json.dumps(exclusions,indent=2));results=[];counts=[]
for policy,excluded in exclusions.items():
 for fold,m in enumerate(museums):
  rr=[r for r in allrows if r['museum']==m];keep=np.array([r['image_file'] not in excluded for r in rr]);y=np.array([classes.index(r['medium']) for r in rr]);ct=np.bincount(y[keep],minlength=17);assert min(ct)>0;counts.append(dict(policy=policy,museum=m,removed=int(sum(~keep)),remaining=int(sum(keep)),min_class_count=int(min(ct))))
  rng=np.random.default_rng(20261024+fold);weights=np.zeros((5000,len(rr)))
  for c in range(17):
   ix=np.flatnonzero((y==c)&keep);weights[:,ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)),size=5000)/(17*len(ix))
  for enc in ['convnext','dinov2']:
   base=np.load(Q/f'head_{enc}_{fold}_0_append.npz')['baseline_pred'];base_correct=base==y;base_ba=np.mean([base_correct[(y==c)&keep].mean() for c in range(17)])
   for method in ['target_only','append','balanced','easyadapt']:
    for budget in [1,3,5]:
     correct=np.array([preds[f'head_{enc}_{fold}_{seed}_{budget}_{method}']==y for seed in range(10)],dtype=float);avg=correct.mean(0);diff=avg-base_correct;gain=np.mean([diff[(y==c)&keep].mean() for c in range(17)]);lo,hi=np.quantile(weights@diff,[.025,.975]);results.append(dict(policy=policy,encoder=enc,museum=m,method=method,budget=budget,source_ba=float(base_ba),adapted_ba=float(base_ba+gain),gain_pp=float(100*gain),lower_pp=float(100*lo),upper_pp=float(100*hi)))
for name,rr in [('sensitivity.csv',results),('remaining_counts.csv',counts)]:
 with (R/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
(R/'summary.json').write_text(json.dumps({'images_decoded':3548,'confirmation_images':1008,'candidate_pairs':len(pairs),'phash_pairs':sum('phash_le6' in p['reasons'] for p in pairs),'automatic_flags':sum(p['automatic_flag'] for p in pairs),'same_composition_pairs':len(composition),'identity_unresolved_pairs':len(unclear),'screened_distinct_pairs':len(pairs)-len(composition)-len(unclear),'exclusion_counts':{k:len(v) for k,v in exclusions.items()},'remaining':counts,'new_training':False},indent=2))
lines=['# 近重复与作品关联复核','', '恢复并校验723,471,982字节的固定公开小图档案，重新解码2,540张开发图片及1,008张确认图片；确认图像RGB与224裁剪哈希全部与历史记录一致。','', '## 筛查与目视复核','', f'对所有涉及确认图片的配对按原开发期pHash64汉明距离≤6筛查，得到40对；结合固定数量的双编码器特征近邻候选，去重后共80对，均已由助手查看联系表。原有自动重复判据没有标记任何一对，但目视发现11对同构图版画或复现图像。','', '“同构图”可能对应不同印次，不能直接称为同一件实物。40对归为设计/系列相近且身份未定，另29对可见不同构图或实物细节。以上为助手低分辨率视觉初审，没有替代官方目录的作品、版次认定。','', '## 不改训练的敏感性分析','', '保留原评价，另设两个排除口径：A排除同构图候选涉及的确认图片；B排除全部80对候选涉及的确认图片。B包括明显不同的器物，是有意从严的压力测试，不将所有候选宣布为泄漏，也不作为新的主测试集。两种口径均不依据识别正误选图；所有方法和预算使用同一排除清单，不调参、不重训。','', '|口径|剔除确认图片|剩余确认图片|','|---|---:|---:|']
for p,ex in exclusions.items():lines.append(f'|{p}|{len(ex)}|{1008-len(ex)}|')
lines+=['','## 每馆85标签、固定EasyAdapt','', '|口径|编码器|馆|收益/百分点|95%条件区间|','|---|---|---|---:|---|']
for r in results:
 if r['method']=='easyadapt' and r['budget']==5:lines.append(f"|{r['policy']}|{r['encoder']}|{r['museum']}|{r['gain_pp']:+.2f}|[{r['lower_pp']:+.2f}, {r['upper_pp']:+.2f}]|")
lines+=['','区间按类对剩余确认组进行5,000次重采样，先对10组固定支持抽样取平均；条件于现有训练和支持数据，不是对新馆总体的保证。候选筛选不是穷举语义作品关联，未排除全部未被筛出的同作品/版次关系。','', '本轮结果应作为稳健性补充，原始结果不能直接改名为作品完全独立的结果。需要在正文说明启发式分组、近重复筛查、视觉复核和敏感性排除的不同含义。','', '文件：contact_*.jpg为80对联系表；reviewed_candidates.json为逐对判断；excluded_confirmation_images.json为两种排除清单；sensitivity.csv包含所有方法和预算；summary.json给出计数；screen.py和sensitivity.py为可复现代码。']
(R/'先看这里.md').write_text('\n'.join(lines),encoding='utf-8')
z=R.parent/'museum_visual_audit_v01_results.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for p in sorted(R.iterdir()):
  if p.is_file():f.write(p,R.name+'/'+p.name)
print((R/'summary.json').read_text());print('\n'.join(lines[16:36]));print('ZIP',z.stat().st_size)
