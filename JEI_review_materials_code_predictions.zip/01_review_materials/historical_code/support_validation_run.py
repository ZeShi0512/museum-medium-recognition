import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import pathlib,json,csv,hashlib,concurrent.futures,time
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import balanced_accuracy_score
R=pathlib.Path(__file__).resolve().parent;W=R.parent/'draft_work';B=W/'museum_data_gate_v01';Q=W/'museum_confirmation_v01';CAL=W/'museum_calibration_v01';METHODS=['target_only','append','balanced','easyadapt'];GRID=[.1,1.,10.]
def ba(y,p):return float(balanced_accuracy_score(y,p))
def design(x,y,src,t,method):
 if method=='target_only':return x[t],y[t],np.ones(len(t))
 if method=='easyadapt':return np.r_[np.c_[x[src],x[src],np.zeros_like(x[src])],np.c_[x[t],np.zeros_like(x[t]),x[t]]],y[np.r_[src,t]],np.ones(len(src)+len(t))
 tr=np.r_[src,t];w=np.ones(len(tr))
 if method=='balanced':w[:len(src)]=len(tr)/(2*len(src));w[len(src):]=len(tr)/(2*len(t))
 return x[tr],y[tr],w
def transformed(x,method):return np.c_[x,np.zeros_like(x),x] if method=='easyadapt' else x
def worker(job):
 enc,fold,m=job;start=time.perf_counter();x=np.load(B/f'features_{enc}.npz')['features'].astype(float);base=np.load(B/f'predictions_{enc}_fold{fold}.npz');y=base['labels'];src=base['train_indices'];samples=json.loads((CAL/'calibration_samples.json').read_text());cv=[];selection=[];outputs=[];fits=0
 for s in samples:
  if s['museum']!=m or s['seed']>=10 or s['per_class_budget']!=5:continue
  t=np.array(s['indices']);assert len(t)==85 and not set(t)&set(src);assert np.all(np.bincount(y[t],minlength=17)==5)
  splits=list(StratifiedKFold(5,shuffle=True,random_state=20261024+s['seed']).split(t,y[t]));foldpreds=[]
  for method in METHODS:
   scores=[]
   for c in GRID:
    oof=np.full(85,-1,dtype=int)
    for k,(train,val) in enumerate(splits):
     assert not set(t[train])&set(t[val]);xx,yy,w=design(x,y,src,t[train],method);h=LogisticRegression(C=c,solver='lbfgs',tol=1e-8,max_iter=2000).fit(xx,yy,sample_weight=w);assert h.n_iter_[0]<2000;fits+=1;oof[val]=h.predict(transformed(x[t[val]],method))
    assert np.all(oof>=0);correct=int(np.sum(oof==y[t]));scores.append(correct);cv.append(dict(encoder=enc,museum=m,seed=s['seed'],method=method,C=c,oof_correct=correct,oof_total=85,oof_ba=correct/85));foldpreds.append(oof)
   best=int(np.argmax(scores));selection.append(dict(encoder=enc,museum=m,seed=s['seed'],method=method,C=GRID[best],cv_ba=scores[best]/85))
  print(enc,fold,'CV seed',s['seed'],'complete',flush=True)
 # Commit selections before loading confirmation features or labels for this job.
 selpath=R/f'selection_{enc}_{fold}.json';selpath.write_text(json.dumps(selection,indent=2));lock=hashlib.sha256(selpath.read_bytes()).hexdigest();(R/f'cv_{enc}_{fold}.json').write_text(json.dumps(cv,indent=2))
 rows=list(csv.DictReader((Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv').open(encoding='utf-8-sig')));classes=json.loads((B/'grouping_correction.json').read_text())['eligible_classes'];q=np.load(Q/f'features_{enc}.npz');assert list(q['ids'])==[r['image_file'] for r in rows];ii=np.array([i for i,r in enumerate(rows) if r['museum']==m]);test=q['features'][ii].astype(float);labels=np.array([classes.index(rows[i]['medium']) for i in ii]);bp=(test@base['coef'].T+base['intercept']).argmax(1);baseline=ba(labels,bp)
 for s in samples:
  if s['museum']!=m or s['seed']>=10 or s['per_class_budget'] not in [1,3,5]:continue
  t=np.array(s['indices']);b=s['per_class_budget'];proto=np.array([x[t[y[t]==c]].mean(0) for c in range(17)]);dist=np.sum(test*test,axis=1)[:,None]+np.sum(proto*proto,axis=1)[None,:]-2*test@proto.T;pred=dist.argmin(1)
  np.savez_compressed(R/f'head_{enc}_{fold}_{s["seed"]}_{b}_prototype.npz',prototypes=proto,pred=pred,labels=labels,eval_indices=ii,baseline_pred=bp)
  outputs.append(dict(encoder=enc,museum=m,seed=s['seed'],budget=b,method='prototype',C=None,ba=ba(labels,pred),baseline_ba=baseline,gain=ba(labels,pred)-baseline))
  if b!=5:continue
  for method in METHODS:
   c=next(r['C'] for r in selection if r['seed']==s['seed'] and r['method']==method);xx,yy,w=design(x,y,src,t,method);h=LogisticRegression(C=c,solver='lbfgs',tol=1e-8,max_iter=2000).fit(xx,yy,sample_weight=w);assert h.n_iter_[0]<2000;fits+=1;pred=h.predict(transformed(test,method));assert np.array_equal(pred,(transformed(test,method)@h.coef_.T+h.intercept_).argmax(1))
   np.savez_compressed(R/f'head_{enc}_{fold}_{s["seed"]}_5_{method}.npz',coef=h.coef_,intercept=h.intercept_,pred=pred,labels=labels,eval_indices=ii,baseline_pred=bp)
   outputs.append(dict(encoder=enc,museum=m,seed=s['seed'],budget=5,method=method,C=c,ba=ba(labels,pred),baseline_ba=baseline,gain=ba(labels,pred)-baseline))
 (R/f'records_{enc}_{fold}.json').write_text(json.dumps(outputs,indent=2));receipt=dict(encoder=enc,museum=m,fold=fold,fits=fits,selection_sha256=lock,elapsed_seconds=time.perf_counter()-start);(R/f'receipt_{enc}_{fold}.json').write_text(json.dumps(receipt,indent=2));return receipt
if __name__=='__main__':
 rows=list(csv.DictReader((Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv').open(encoding='utf-8-sig')));museums=sorted({r['museum'] for r in rows})
 protocol={'C_grid':GRID,'target_budget_for_cv':85,'cv':'StratifiedKFold5 shuffle=True random_state=20261024+support_seed; 4 training and 1 validation target images per class; source rows fixed','selection':'maximize integer OOF correct count over all 85 target support images; ties choose smaller C; no confirmation labels used; selections committed before confirmation features load in each job','methods':METHODS,'prototype':'mean of original L2-normalized target support features; do not normalize mean again; squared Euclidean nearest mean; all 1/3/5 budgets','seeds':list(range(10)),'encoders':['convnext','dinov2'],'inference':'confirmation already exposed, exploratory appended fairness check; no new independent replication','script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()};(R/'protocol_frozen.json').write_text(json.dumps(protocol,indent=2))
 with concurrent.futures.ProcessPoolExecutor(max_workers=6) as pool:
  jobs=[(enc,f,m) for enc in ['convnext','dinov2'] for f,m in enumerate(museums)]
  for result in pool.map(worker,jobs):print('JOB_DONE',json.dumps(result),flush=True)
