import pathlib,csv,json,zipfile,io,hashlib
import numpy as np
from PIL import Image,ImageDraw
from scipy.fft import dctn
R=pathlib.Path(__file__).resolve().parent;W=R.parent/'draft_work';B=W/'museum_data_gate_v01';Q=W/'museum_confirmation_v01';D=W/'museum_budget_v01'
protocol={'screening':'Full-image pHash64 Hamming<=6 for all pairs involving confirmation; image-only rule previously used on development','automatic_flag':'pHash<=6 AND RGB64 MAE<=0.025 AND RGB64 correlation>=0.99','secondary_screen':'top20 nearest development-confirmation feature pairs per encoder, plus top10 confirmation-confirmation per encoder; cosine on saved normalized features, no label or outcome filtering','review':'Look at candidate photographs; visual similarity alone does not establish catalogue work identity. Report ambiguous pairs and evaluate sensitivity, do not rewrite labels or tune models.','new_training':False}
(R/'protocol.json').write_text(json.dumps(protocol,indent=2))
def csvread(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
dev=csvread(B/'grouped_image_audit/pilot_manifest_after_image_gate.csv');test=csvread(Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv');rows=[dict(r,role='development') for r in dev]+[dict(r,role='confirmation') for r in test];nd=len(dev);images=[];thumbs=[];hashes=[];receipts=[]
with zipfile.ZipFile(B/'small.zip') as z:
 inv={pathlib.Path(n).name:n for n in z.namelist()}
 for i,r in enumerate(rows):
  b=z.read(inv[r['image_file']]);im=Image.open(io.BytesIO(b)).convert('RGB');im.load();assert im.size==(256,256);images.append(im);a=np.asarray(im);rgb=hashlib.sha256(str(a.shape).encode()+a.tobytes()).hexdigest();crop=hashlib.sha256(np.asarray(im.crop((16,16,240,240))).tobytes()).hexdigest()
  if i>=nd:assert rgb==r['rgb_sha256'] and crop==r['input224_sha256']
  g=np.asarray(im.convert('L').resize((32,32),Image.Resampling.LANCZOS),dtype=float);d=dctn(g,type=2,norm='ortho')[:8,:8].ravel();bits=d>np.median(d[1:]);bits[0]=False;ph=int.from_bytes(np.packbits(bits).tobytes(),'big');hashes.append(ph);thumbs.append(np.asarray(im.resize((64,64),Image.Resampling.BILINEAR),dtype=float)/255);receipts.append(dict(image_file=r['image_file'],role=r['role'],phash64=f'{ph:016x}',rgb_sha256=rgb,input224_sha256=crop))
print('Images decoded and hashes checked',len(rows),flush=True)
pairs={}
def add(i,j,reason,score=None):
 i,j=sorted((i,j));key=(i,j)
 if key not in pairs:
  x=thumbs[i].ravel();y=thumbs[j].ravel();mae=float(np.mean(abs(x-y)));corr=float(np.corrcoef(x,y)[0,1]);hd=(hashes[i]^hashes[j]).bit_count();pairs[key]=dict(a=i,b=j,a_file=rows[i]['image_file'],b_file=rows[j]['image_file'],a_role=rows[i]['role'],b_role=rows[j]['role'],a_museum=rows[i]['museum'],b_museum=rows[j]['museum'],a_medium=rows[i]['medium'],b_medium=rows[j]['medium'],hamming=hd,mae64=mae,corr64=corr,automatic_flag=bool(hd<=6 and mae<=.025 and corr>=.99),reasons=[],scores={})
 pairs[key]['reasons'].append(reason)
 if score is not None:pairs[key]['scores'][reason]=float(score)
for j in range(nd,len(rows)):
 for i in range(j):
  if (hashes[i]^hashes[j]).bit_count()<=6:add(i,j,'phash_le6')
for enc in ['convnext','dinov2']:
 a=np.load(B/f'features_{enc}.npz');b=np.load(Q/f'features_{enc}.npz');assert list(a['ids'])==[r['image_file'] for r in dev];assert list(b['ids'])==[r['image_file'] for r in test];x=a['features'].astype(float);y=b['features'].astype(float);x/=np.linalg.norm(x,axis=1,keepdims=True);y/=np.linalg.norm(y,axis=1,keepdims=True)
 sim=x@y.T;idx=np.argsort(sim.ravel())[-20:][::-1]
 for v in idx:i,j=np.unravel_index(v,sim.shape);add(int(i),int(nd+j),'feature_dev_'+enc,sim[i,j])
 sim=y@y.T;sim[np.tril_indices(len(y))]=-2;idx=np.argsort(sim.ravel())[-10:][::-1]
 for v in idx:i,j=np.unravel_index(v,sim.shape);add(nd+int(i),nd+int(j),'feature_test_'+enc,sim[i,j])
pp=sorted(pairs.values(),key=lambda p:(not p['automatic_flag'],p['hamming'],p['a'],p['b']))
for k,p in enumerate(pp):p['review_id']=f'V{k+1:03d}'
(R/'candidates.json').write_text(json.dumps(pp,indent=2));(R/'image_hashes.json').write_text(json.dumps(receipts,indent=2))
for start in range(0,len(pp),12):
 subset=pp[start:start+12];canvas=Image.new('RGB',(1200,312*((len(subset)+1)//2)),(245,245,245));draw=ImageDraw.Draw(canvas)
 for k,p in enumerate(subset):
  x=(k%2)*600;y=(k//2)*312
  for side,idx in enumerate([p['a'],p['b']]):canvas.paste(images[idx].resize((256,256)),(x+side*280,y+45))
  draw.text((x+3,y+2),f"{p['review_id']} hd={p['hamming']} MAE={p['mae64']:.3f} corr={p['corr64']:.3f}",fill='black');draw.text((x+3,y+18),p['a_file']+' | '+p['b_file'],fill='black');draw.text((x+3,y+301),p['a_role']+' | '+p['b_role'],fill='black')
 canvas.save(R/f'contact_{start//12+1:02d}.jpg',quality=90)
print('CANDIDATES',len(pp),'phash',sum('phash_le6' in p['reasons'] for p in pp),'automatic',sum(p['automatic_flag'] for p in pp),flush=True)
