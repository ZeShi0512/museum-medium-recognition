import pathlib,csv,json,zipfile,hashlib,collections
import numpy as np
from sklearn.metrics import balanced_accuracy_score
R=pathlib.Path(__file__).resolve().parent;P=R.parent;W=P/'draft_work';B=W/'museum_data_gate_v01';Q=W/'museum_confirmation_v01';D=W/'museum_budget_v01';rows=list(csv.DictReader((Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv').open(encoding='utf-8-sig')));museums=sorted({r['museum'] for r in rows});classes=json.loads((B/'grouping_correction.json').read_text())['eligible_classes'];records=[];models=0;checks=0;arrays={};c1checks=0
for enc in ['convnext','dinov2']:
 xx=np.load(Q/f'features_{enc}.npz')['features'].astype(float)
 for fold,m in enumerate(museums):
  rec=json.loads((R/f'records_{enc}_{fold}.json').read_text());records+=rec;selection=json.loads((R/f'selection_{enc}_{fold}.json').read_text());cv=json.loads((R/f'cv_{enc}_{fold}.json').read_text());receipt=json.loads((R/f'receipt_{enc}_{fold}.json').read_text());assert receipt['selection_sha256']==hashlib.sha256((R/f'selection_{enc}_{fold}.json').read_bytes()).hexdigest()
  for sel in selection:
   cc=sorted([z for z in cv if z['seed']==sel['seed'] and z['method']==sel['method']],key=lambda z:z['C']);best=max(cc,key=lambda z:z['oof_correct']);assert best['C']==sel['C']
  for r in rec:
   stem=f'head_{enc}_{fold}_{r["seed"]}_{r["budget"]}_{r["method"]}';a=np.load(R/(stem+'.npz'));x=xx[a['eval_indices']];y=a['labels']
   if r['method']=='prototype':proto=a['prototypes'];pred=(np.sum(x*x,1)[:,None]+np.sum(proto*proto,1)[None,:]-2*x@proto.T).argmin(1)
   else:
    if r['method']=='easyadapt':x=np.c_[x,np.zeros_like(x),x]
    pred=(x@a['coef'].T+a['intercept']).argmax(1)
   assert np.array_equal(pred,a['pred']);assert abs(balanced_accuracy_score(y,pred)-r['ba'])<1e-12;models+=1;checks+=len(y);arrays[stem]=pred
   if r['C']==1:
    old=(Q if r['method'] in ['append','balanced'] else W/'museum_controls_v01')/f'head_{enc}_{fold}_{r["seed"]}_{r["method"]}.npz';assert np.array_equal(pred,np.load(old)['pred']);c1checks+=1
np.savez_compressed(R/'all_predictions.npz',**arrays);summary=[]
for enc in ['convnext','dinov2']:
 for m in museums:
  for method in ['prototype','target_only','append','balanced','easyadapt']:
   for b in ([1,3,5] if method=='prototype' else [5]):
    rr=[r for r in records if r['encoder']==enc and r['museum']==m and r['method']==method and r['budget']==b];assert len(rr)==10;summary.append(dict(encoder=enc,museum=m,method=method,budget=b,mean_ba=float(np.mean([r['ba'] for r in rr])),mean_gain=float(np.mean([r['gain'] for r in rr])),selected_C_counts=dict(collections.Counter(str(r['C']) for r in rr))))
(R/'summary.json').write_text(json.dumps(summary,indent=2));(R/'records.json').write_text(json.dumps(records,indent=2))
excluded=set(json.loads((P/'museum_visual_audit_v01/excluded_confirmation_images.json').read_text())['all_screened_candidates']);intervals=[]
for fold,m in enumerate(museums):
 rr=[r for r in rows if r['museum']==m];y=np.array([classes.index(r['medium']) for r in rr])
 for policy in ['original','exclude_all_candidates']:
  keep=np.ones(len(y),dtype=bool) if policy=='original' else np.array([r['image_file'] not in excluded for r in rr]);rng=np.random.default_rng(20261024+fold);weight=np.zeros((5000,len(y)))
  for c in range(17):
   ix=np.flatnonzero((y==c)&keep);assert len(ix)>0;weight[:,ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)),size=5000)/(17*len(ix))
  for enc in ['convnext','dinov2']:
   easy=np.mean([arrays[f'head_{enc}_{fold}_{seed}_5_easyadapt']==y for seed in range(10)],axis=0)
   for comparator in ['source_only','target_only','prototype']:
    if comparator=='source_only':other=np.load(R/f'head_{enc}_{fold}_0_5_easyadapt.npz')['baseline_pred']==y
    else:other=np.mean([arrays[f'head_{enc}_{fold}_{seed}_5_{comparator}']==y for seed in range(10)],axis=0)
    diff=easy-other;g=np.mean([diff[(y==c)&keep].mean() for c in range(17)]);lo,hi=np.quantile(weight@diff,[.025,.975]);intervals.append(dict(policy=policy,encoder=enc,museum=m,comparison='tuned_easyadapt_minus_'+comparator,gain_pp=100*float(g),lower_pp=100*float(lo),upper_pp=100*float(hi)))
with (R/'paired_intervals.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(intervals[0]));w.writeheader();w.writerows(intervals)
def v(enc,m,method):return next(r['mean_ba'] for r in summary if r['encoder']==enc and r['museum']==m and r['method']==method and r['budget']==5)*100
lines=['# 基线公平性检查','', '本轮没有重训编码器。每馆85标签内部5折分层验证，每折每类4张训练、1张验证；固定C={0.1,1,10}，10组原支持抽样，所有方法同规则，同分选小C。确认图片不参与选参。原型基线用支持特征均值和平方欧氏距离，不二次归一化均值。','', '|编码器|馆|本馆原型|本馆选参LR|追加选参|域加权选参|EasyAdapt选参|','|---|---|---:|---:|---:|---:|---:|']
for enc in ['convnext','dinov2']:
 for m in museums:lines.append('|'+ '|'.join([enc,m]+[f'{v(enc,m,method):.2f}' for method in ['prototype','target_only','append','balanced','easyadapt']])+'|')
lines+=['','## 配对收益与条件区间','', '|评价口径|编码器|馆|比较|差异/百分点|95%条件区间|','|---|---|---|---|---:|---|']
for r in intervals:lines.append(f"|{r['policy']}|{r['encoder']}|{r['museum']}|{r['comparison']}|{r['gain_pp']:+.2f}|[{r['lower_pp']:+.2f}, {r['upper_pp']:+.2f}]|")
lines+=['','## 解释边界','', '本轮是确认集已曝光后的追加公平性分析，不是新的独立盲测。参数只在固定三点网格中选择，不代表全参数空间最优；若频繁选中网格端点，应在论文中明确范围，不基于确认结果扩网格。','', '区间为5,000次按类配对重采样，条件于既有源数据、编码器及10组支持集；先平均支持集正确性，不将重叠抽样当成独立测试集。未作多重比较校正。','', '原型方法是冻结表示上的简单目标基线，不是复现2025年少样本中国画论文的训练网络。','', f'独立重算{models}个模型的{checks:,}条预测及全部BA；其中{c1checks}个选中C=1的头与原固定参数预测逐项一致。','', '原先固定C结果不删除。正文需要根据公平选参后的结果重新组织，不能只保留有利排名。']
(R/'先看这里.md').write_text('\n'.join(lines),encoding='utf-8');cvfits=sum(json.loads(p.read_text())['fits'] for p in R.glob('receipt_*.json'));(R/'verification.json').write_text(json.dumps(dict(models=models,prediction_checks=checks,C1_reproduction_checks=c1checks,cv_and_refit_count=cvfits,cv_selection_reconstructed=True),indent=2))
z=P/'museum_fairness_v01_results.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for p in sorted(R.iterdir()):
  if p.is_file() and not p.name.startswith('head_') and p.name!='progress.log':f.write(p,R.name+'/'+p.name)
print('\n'.join(lines[:12]));print('verification',models,checks,'fits',cvfits);print('ZIP',z.stat().st_size)
