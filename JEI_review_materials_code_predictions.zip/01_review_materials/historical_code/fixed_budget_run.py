import csv,json,pathlib,hashlib,time
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
R=pathlib.Path(__file__).resolve().parent;B=R.parent/'museum_data_gate_v01';Q=R.parent/'museum_confirmation_v01';C=R.parent/'museum_calibration_v01';K=R.parent/'museum_controls_v01'
P={'budgets_per_class':[1,3,5],'methods':['target_only','append','balanced','easyadapt'],'seeds':list(range(10)),'C':1,'tol':1e-8,'max_iter':2000,'selection':'fixed parameters, no test selection','evaluation':'previously exposed 1008 confirmation images; descriptive budget comparison','reuse':'budget5 saved heads reused and predictions reconstructed','script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
(R/'protocol.json').write_text(json.dumps(P,indent=2))
rows=list(csv.DictReader((Q/'grouped_image_audit/pilot_manifest_after_image_gate.csv').open(encoding='utf-8-sig')));classes=json.loads((B/'grouping_correction.json').read_text())['eligible_classes'];museums=sorted({r['museum'] for r in rows});samples=json.loads((C/'calibration_samples.json').read_text());records=[]
for enc in ['convnext','dinov2']:
 x=np.load(B/f'features_{enc}.npz')['features'].astype(float);q=np.load(Q/f'features_{enc}.npz');assert list(q['ids'])==[r['image_file'] for r in rows];xx=q['features'].astype(float)
 for fold,m in enumerate(museums):
  a=np.load(B/f'predictions_{enc}_fold{fold}.npz');y=a['labels'];src=a['train_indices'];ii=np.array([i for i,r in enumerate(rows) if r['museum']==m]);yy=np.array([classes.index(rows[i]['medium']) for i in ii]);basepred=(xx[ii]@a['coef'].T+a['intercept']).argmax(1);base=float(balanced_accuracy_score(yy,basepred))
  for s in samples:
   budget=s['per_class_budget']
   if s['museum']!=m or s['seed']>=10 or budget not in P['budgets_per_class']:continue
   t=np.array(s['indices']);assert len(t)==17*budget
   for method in P['methods']:
    test=xx[ii];seconds=None
    if method=='easyadapt':test=np.c_[test,np.zeros_like(test),test]
    if budget==5:
     old=(Q if method in ['append','balanced'] else K)/f'head_{enc}_{fold}_{s["seed"]}_{method}.npz';saved=np.load(old);coef=saved['coef'];intercept=saved['intercept'];pred=(test@coef.T+intercept).argmax(1);assert np.array_equal(pred,saved['pred'])
    else:
     if method=='target_only':train=x[t];labels=y[t];w=np.ones(len(t))
     elif method=='easyadapt':train=np.r_[np.c_[x[src],x[src],np.zeros_like(x[src])],np.c_[x[t],np.zeros_like(x[t]),x[t]]];labels=y[np.r_[src,t]];w=np.ones(len(labels))
     else:
      tr=np.r_[src,t];train=x[tr];labels=y[tr];w=np.ones(len(tr))
      if method=='balanced':w[:len(src)]=len(tr)/(2*len(src));w[len(src):]=len(tr)/(2*len(t))
     start=time.perf_counter();h=LogisticRegression(C=1,solver='lbfgs',tol=1e-8,max_iter=2000).fit(train,labels,sample_weight=w);seconds=time.perf_counter()-start;assert h.n_iter_[0]<2000;assert np.array_equal(h.classes_,np.arange(17));coef=h.coef_;intercept=h.intercept_;pred=h.predict(test);assert np.array_equal(pred,(test@coef.T+intercept).argmax(1))
    ba=float(balanced_accuracy_score(yy,pred));np.savez_compressed(R/f'head_{enc}_{fold}_{s["seed"]}_{budget}_{method}.npz',coef=coef,intercept=intercept,pred=pred,labels=yy,eval_indices=ii)
    records.append(dict(encoder=enc,museum=m,seed=s['seed'],budget=budget,total_labels=len(t),method=method,ba=ba,baseline_ba=base,gain=ba-base,reused=budget==5,fit_seconds=seconds))
  (R/'records.json').write_text(json.dumps(records,indent=2));print(enc,m,'completed',flush=True)
summary=[]
for enc in ['convnext','dinov2']:
 for m in museums:
  for method in P['methods']:
   for b in P['budgets_per_class']:
    rr=[r for r in records if r['encoder']==enc and r['museum']==m and r['method']==method and r['budget']==b];summary.append(dict(encoder=enc,museum=m,method=method,budget=b,mean_ba=float(np.mean([r['ba'] for r in rr])),mean_gain=float(np.mean([r['gain'] for r in rr])),positive_draws=sum(r['gain']>0 for r in rr)))
(R/'summary.json').write_text(json.dumps(summary,indent=2));print('DONE',len(records),flush=True)
