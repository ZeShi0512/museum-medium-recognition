"""Frozen, CPU-only image encoders. No label-dependent fitting."""
import argparse,csv,hashlib,json,sys,time,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
import torch

R=Path(__file__).resolve().parent
p=json.loads((R/'protocol_frozen.json').read_text())
parser=argparse.ArgumentParser();parser.add_argument('encoder',choices=['convnext','dinov2']);enc=parser.parse_args().encoder
assert json.loads((R/'grouped_image_audit/image_audit.json').read_text())['gate_passed']
manifest=R/'grouped_image_audit/pilot_manifest_after_image_gate.csv'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==p['manifest_sha256']
rows=list(csv.DictReader(manifest.open(encoding='utf-8-sig',newline='')))
torch.set_num_threads(8);torch.set_num_interop_threads(1);torch.manual_seed(20261024)
torch.use_deterministic_algorithms(True)
if enc=='convnext':
    from torchvision.models import convnext_tiny
    model=convnext_tiny(weights=None).eval();weights=R/'assets/convnext_tiny.pth'
    def encode(x):return model.classifier[1](model.classifier[0](model.avgpool(model.features(x))))
else:
    sys.path.insert(0,str(R/'assets/dinov2-7764ea0f912e53c92e82eb78a2a1631e92725fc8'))
    from dinov2.hub.backbones import dinov2_vits14
    model=dinov2_vits14(pretrained=False).eval();weights=R/'assets/dinov2_vits14.pth'
    def encode(x):return model(x)
assert hashlib.sha256(weights.read_bytes()).hexdigest()==p['models'][enc]['weight_sha256']
model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True),strict=True)
def tensor(row):
    im=Image.open(R/'images'/row['image_file']).convert('RGB')
    assert im.size==(256,256)
    a=np.asarray(im.crop((16,16,240,240)),dtype=np.float32)/255
    a=(a-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)
    return torch.from_numpy(a.transpose(2,0,1).copy())
path=R/f'features_{enc}.npz';features=[];ids=[r['image_file'] for r in rows]
if path.exists():
    with np.load(path) as old:
        assert list(old['ids'])==ids[:len(old['ids'])];features=list(old['features'])
started=time.monotonic()
for i in range(len(features),len(rows),16):
    with torch.inference_mode():
        z=torch.nn.functional.normalize(encode(torch.stack([tensor(r) for r in rows[i:i+16]])),dim=-1).numpy()
    assert np.isfinite(z).all();features.extend(z)
    if len(features)%128==0 or len(features)==len(rows):
        tmp=R/f'features_{enc}.checkpoint.npz'
        np.savez_compressed(tmp,ids=np.array(ids[:len(features)]),features=np.array(features,dtype=np.float32))
        with zipfile.ZipFile(tmp) as f:assert f.testzip() is None
        tmp.replace(path)
        print(enc,len(features),'/',len(rows),'elapsed',round(time.monotonic()-started,1),flush=True)
(R/f'feature_receipt_{enc}.json').write_text(json.dumps({'encoder':enc,'records':len(rows),'features_shape':list(np.array(features).shape),'weight_sha256':p['models'][enc]['weight_sha256'],'feature_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((R/'protocol_frozen.json').read_bytes()).hexdigest(),'seconds_this_run':time.monotonic()-started},indent=2)+'\n')
print('FEATURES_COMPLETE',enc,flush=True)
