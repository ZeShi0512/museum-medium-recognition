"""Verify archived predictions, summaries and paired intervals without image models.

Run from any directory: python 01_review_materials/code/verify_results.py
Only NumPy is required. No network, model fitting or image download is performed.
"""
from pathlib import Path
import csv, hashlib, json
import numpy as np

R=Path(__file__).resolve().parents[1]
def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def ba(y,p):return float(np.mean([np.mean(p[y==c]==c) for c in range(17)]))
def close(a,b):
    if not np.isclose(a,b,atol=1e-10,rtol=0):raise AssertionError((a,b))
def check(condition,message):
    if not condition:raise AssertionError(message)

def main():
    dev=readcsv(R/'data/development_manifest.csv'); conf=readcsv(R/'data/confirmation_manifest.csv')
    classes=load(R/'data/classes.json'); museums=load(R/'data/museums.json')
    check(len(dev)==2540 and len(conf)==1008,'image counts')
    check(len({r['family_key'] for r in conf})==1008,'confirmation family uniqueness')
    check(not ({r['family_key'] for r in dev}&{r['family_key'] for r in conf}),'family overlap')
    samples=load(R/'data/support_draws.json')
    check(len(samples)==90,'support draw count')
    for s in samples:
        ix=s['indices']; b=s['per_class_budget']
        check(len(ix)==17*b and len(set(ix))==len(ix),'support sizes')
        check(all(dev[i]['museum']==s['museum'] and dev[i]['target_support_pool']=='True' for i in ix),'support role')
        check(all(sum(dev[i]['medium']==c for i in ix)==b for c in classes),'support class balance')
    for m in museums:
        for seed in range(10):
            sets=[set(next(s['indices'] for s in samples if s['museum']==m and s['seed']==seed and s['per_class_budget']==b)) for b in [1,3,5]]
            check(sets[0]<=sets[1]<=sets[2],'nested budgets')
    selections=load(R/'data/selected_C.json'); cv=load(R/'data/CV_scores.json')
    check(len(selections)==240 and len(cv)==720,'CV record counts')
    for s in selections:
        choices=sorted([c for c in cv if all(c[k]==s[k] for k in ['encoder','museum','seed','method'])],key=lambda c:c['C'])
        check(len(choices)==3,'C grid size')
        best=max(choices,key=lambda c:c['oof_correct'])
        check(best['C']==s['C'],'C selection and tie rule')
    arrays={'fixed':np.load(R/'results/fixed_predictions.npz'), 'validated':np.load(R/'results/validated_predictions.npz')}
    source=np.load(R/'results/source_predictions.npz')
    checked=0; prediction_count=0; table_cells=0
    for mode in ['fixed','validated']:
        records=load(R/f'results/{mode}_records.json')
        check(len(records)==(720 if mode=='fixed' else 420),'record count')
        check(len(arrays[mode].files)==len(records),'prediction array count')
        for record in records:
            fold=museums.index(record['museum']); rows=[r for r in conf if r['museum']==record['museum']]
            y=np.array([classes.index(r['medium']) for r in rows])
            key=f"head_{record['encoder']}_{fold}_{record['seed']}_{record['budget']}_{record['method']}"
            pred=arrays[mode][key]
            check(pred.shape==y.shape and np.all((pred>=0)&(pred<17)),'prediction dimensions')
            score=ba(y,pred); baseline=ba(y,source[f"{record['encoder']}_{fold}"])
            close(score,record['ba']); close(baseline,record['baseline_ba']); close(score-baseline,record['gain'])
            checked+=1; prediction_count+=len(y)
        for summary in load(R/f'results/{mode}_summary.json'):
            rr=[r for r in records if all(r[k]==summary[k] for k in ['encoder','museum','method','budget'])]
            check(len(rr)==10,'summary support count')
            close(np.mean([r['ba'] for r in rr]),summary['mean_ba']);close(np.mean([r['gain'] for r in rr]),summary['mean_gain'])
            table_cells+=1
    intervals=readcsv(R/'results/validated_paired_intervals.csv')
    excluded=set(load(R/'data/excluded_confirmation_images.json')['all_screened_candidates'])
    check(len(excluded)==54,'strict exclusion count')
    interval_checks=0
    for fold,m in enumerate(museums):
        rows=[r for r in conf if r['museum']==m];y=np.array([classes.index(r['medium']) for r in rows])
        for policy in ['original','exclude_all_candidates']:
            keep=np.ones(len(y),bool) if policy=='original' else np.array([r['image_file'] not in excluded for r in rows])
            rng=np.random.default_rng(20261024+fold);weights=np.zeros((5000,len(y)))
            for c in range(17):
                ix=np.flatnonzero((y==c)&keep); check(len(ix)>0,'retained class')
                weights[:,ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)),size=5000)/(17*len(ix))
            for enc in ['convnext','dinov2']:
                correct=np.mean([arrays['validated'][f'head_{enc}_{fold}_{seed}_5_easyadapt']==y for seed in range(10)],axis=0)
                for comparator in ['source_only','target_only','prototype']:
                    other=(source[f'{enc}_{fold}']==y) if comparator=='source_only' else np.mean([arrays['validated'][f'head_{enc}_{fold}_{seed}_5_{comparator}']==y for seed in range(10)],axis=0)
                    diff=correct-other; gain=100*np.mean([diff[(y==c)&keep].mean() for c in range(17)])
                    lo,hi=100*np.quantile(weights@diff,[.025,.975])
                    old=next(r for r in intervals if r['policy']==policy and r['encoder']==enc and r['museum']==m and r['comparison']=='tuned_easyadapt_minus_'+comparator)
                    for a,k in [(gain,'gain_pp'),(lo,'lower_pp'),(hi,'upper_pp')]:close(a,float(old[k]))
                    interval_checks+=1
    report={'status':'PASS','development_images':len(dev),'confirmation_images':len(conf),'support_draws_checked':len(samples),'C_selections_checked':len(selections),'prediction_sets_checked':checked,'per_image_predictions_checked':prediction_count,'summary_cells_checked':table_cells,'paired_intervals_recomputed':interval_checks,'model_training_performed':False,'network_used':False}
    output=R/'results/verification_report.json';output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
