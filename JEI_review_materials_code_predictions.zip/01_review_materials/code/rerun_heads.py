"""Optional classifier refitting from the separate private feature cache.

Uses only source support and fixed target support for fitting/selection. No backbone
training. Saved confirmation predictions serve as a reproduction check, never as
an input to fitting, C selection, method selection, or support selection.
"""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import argparse,csv,json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold

R=Path(__file__).resolve().parents[1]
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def design(x,y,src,t,method):
    if method=='target_only':return x[t],y[t],np.ones(len(t))
    if method=='easyadapt':
        return np.r_[np.c_[x[src],x[src],np.zeros_like(x[src])],np.c_[x[t],np.zeros_like(x[t]),x[t]]],y[np.r_[src,t]],np.ones(len(src)+len(t))
    tr=np.r_[src,t];w=np.ones(len(tr))
    if method=='balanced':w[:len(src)]=len(tr)/(2*len(src));w[len(src):]=len(tr)/(2*len(t))
    return x[tr],y[tr],w
def transformed(x,method):return np.c_[x,np.zeros_like(x),x] if method=='easyadapt' else x
def fit(x,y,w,c):
    h=LogisticRegression(C=c,solver='lbfgs',tol=1e-8,max_iter=2000).fit(x,y,sample_weight=w)
    if h.n_iter_[0]>=2000:raise RuntimeError('head did not converge')
    return h

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--cache-dir',type=Path,default=R.parent/'02_private_feature_cache')
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--encoder',choices=['convnext','dinov2','all'],default='all')
    ap.add_argument('--fold',type=int,choices=[0,1,2])
    ap.add_argument('--seed',type=int,choices=range(10))
    ap.add_argument('--mode',choices=['fixed','validated','both'],default='both')
    ap.add_argument('--budget',type=int,choices=[1,3,5])
    ap.add_argument('--reselect-c',action='store_true',help='Repeat support-only five-fold C selection; otherwise use archived choices.')
    args=ap.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    dev=rows(R/'data/development_manifest.csv');conf=rows(R/'data/confirmation_manifest.csv')
    classes=json.loads((R/'data/classes.json').read_text());museums=json.loads((R/'data/museums.json').read_text())
    samples=json.loads((R/'data/support_draws.json').read_text());selections=json.loads((R/'data/selected_C.json').read_text())
    y=np.array([classes.index(r['medium']) for r in dev]);count=0;comparisons=[]
    for enc in (['convnext','dinov2'] if args.encoder=='all' else [args.encoder]):
        a=np.load(args.cache_dir/f'development_{enc}.npz');x=a['features'].astype(float)
        if list(a['ids'])!=[r['image_file'] for r in dev]:raise ValueError('development order')
        for fold,museum in enumerate(museums):
            if args.fold is not None and args.fold!=fold:continue
            src=np.array([i for i,r in enumerate(dev) if r['museum']!=museum and r['source_role']=='support'])
            for mode in (['fixed','validated'] if args.mode=='both' else [args.mode]):
                tasks=[];new_selections=[]
                for s in samples:
                    b=s['per_class_budget'];seed=s['seed']
                    if s['museum']!=museum or (args.seed is not None and args.seed!=seed) or (args.budget is not None and args.budget!=b):continue
                    t=np.array(s['indices'])
                    if set(t)&set(src):raise ValueError('support/source overlap')
                    methods=['target_only','append','balanced','easyadapt'] if mode=='fixed' else (['prototype']+(['target_only','append','balanced','easyadapt'] if b==5 else []))
                    for method in methods:
                        c=None if method=='prototype' else 1.
                        if mode=='validated' and method!='prototype':
                            c=next(r['C'] for r in selections if r['encoder']==enc and r['museum']==museum and r['seed']==seed and r['method']==method)
                            if args.reselect_c:
                                scores=[]
                                for candidate in [.1,1.,10.]:
                                    oof=np.full(len(t),-1,dtype=int)
                                    for tr,va in StratifiedKFold(5,shuffle=True,random_state=20261024+seed).split(t,y[t]):
                                        xx,yy,w=design(x,y,src,t[tr],method)
                                        h=fit(xx,yy,w,candidate);oof[va]=h.predict(transformed(x[t[va]],method))
                                    scores.append(int(np.sum(oof==y[t])))
                                selected=[.1,1.,10.][int(np.argmax(scores))]
                                if selected!=c:raise AssertionError('reselected C differs from archived support choice')
                                c=selected;new_selections.append(dict(encoder=enc,fold=fold,seed=seed,method=method,C=c,oof_correct=scores))
                        tasks.append((b,seed,t,method,c))
                # Write support-only decisions before opening confirmation features.
                (args.output_dir/f'{mode}_{enc}_{fold}_selection.json').write_text(json.dumps(new_selections,indent=2))
                q=np.load(args.cache_dir/f'confirmation_{enc}.npz')
                if list(q['ids'])!=[r['image_file'] for r in conf]:raise ValueError('confirmation order')
                ii=np.array([i for i,r in enumerate(conf) if r['museum']==museum]);test=q['features'][ii].astype(float)
                for b,seed,t,method,c in tasks:
                    key=f'head_{enc}_{fold}_{seed}_{b}_{method}'
                    if method=='prototype':
                        proto=np.array([x[t[y[t]==k]].mean(0) for k in range(17)])
                        pred=(np.sum(test*test,1)[:,None]+np.sum(proto*proto,1)[None,:]-2*test@proto.T).argmin(1)
                        params={'prototypes':proto}
                    else:
                        xx,yy,w=design(x,y,src,t,method);h=fit(xx,yy,w,c)
                        pred=h.predict(transformed(test,method));params={'coef':h.coef_,'intercept':h.intercept_}
                    np.savez_compressed(args.output_dir/f'{mode}_{key}.npz',pred=pred,eval_indices=ii,**params)
                    # Reproduction comparison is performed after fitting and prediction.
                    with np.load(R/f'results/{mode}_predictions.npz') as expected:
                        agree=int(np.sum(pred==expected[key]));total=len(pred)
                    comparisons.append(dict(mode=mode,key=key,C=c,identical_predictions=agree,total=total))
                    if agree!=total:raise AssertionError(f'prediction mismatch: {mode} {key}: {agree}/{total}')
                    count+=1;print(f'{count}: reproduced {mode} {key}',flush=True)
    report={'status':'PASS','heads_or_prototypes_checked':count,'reselected_C':args.reselect_c,'comparisons':comparisons}
    (args.output_dir/'refit_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('REFIT_REPRODUCTION_COMPLETE',count,flush=True)

if __name__=='__main__':main()
