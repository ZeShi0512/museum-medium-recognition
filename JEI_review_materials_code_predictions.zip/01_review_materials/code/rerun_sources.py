"""Refit all six source classifiers from separately retained feature caches.
Requires the author cache or features re-extracted in manifest order; no source labels
or confirmation labels are used for parameter selection. Does not re-extract images.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,csv,json
import numpy as np
from sklearn.linear_model import LogisticRegression
R=Path(__file__).resolve().parents[1]
def rows(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--cache-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);args=ap.parse_args()
 dev=rows(R/'data/development_manifest.csv');conf=rows(R/'data/confirmation_manifest.csv')
 classes=json.loads((R/'data/classes.json').read_text());museums=json.loads((R/'data/museums.json').read_text());y=np.array([classes.index(r['medium']) for r in dev]);saved=np.load(R/'results/source_predictions.npz');out=[]
 args.output_dir.mkdir(parents=True,exist_ok=True)
 for enc in ['convnext','dinov2']:
  a=np.load(args.cache_dir/f'development_{enc}.npz');b=np.load(args.cache_dir/f'confirmation_{enc}.npz')
  assert list(a['ids'])==[r['image_file'] for r in dev] and list(b['ids'])==[r['image_file'] for r in conf]
  x=a['features'].astype(float);q=b['features'].astype(float)
  for fold,m in enumerate(museums):
   src=np.array([i for i,r in enumerate(dev) if r['museum']!=m and r['source_role']=='support']);ii=np.array([i for i,r in enumerate(conf) if r['museum']==m])
   h=LogisticRegression(C=1,solver='lbfgs',tol=1e-8,max_iter=2000).fit(x[src],y[src]);assert h.n_iter_[0]<2000
   p=h.predict(q[ii]);assert np.array_equal(p,saved[f'{enc}_{fold}'])
   np.savez_compressed(args.output_dir/f'source_head_{enc}_{fold}.npz',coef=h.coef_,intercept=h.intercept_,pred=p)
   out.append(dict(encoder=enc,fold=fold,predictions_identical=True,n_predictions=len(p)))
   print('Source predictions reproduced',enc,fold,flush=True)
 (args.output_dir/'source_refit_report.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
