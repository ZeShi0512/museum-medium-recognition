import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import csv,json,hashlib
import numpy as np

R=Path(__file__).resolve().parents[1]
O=R/'results';O.mkdir(exist_ok=True)
def rows(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
classes=json.loads((R/'data/classes.json').read_text());museums=json.loads((R/'data/museums.json').read_text())
dev=rows(R/'data/development_manifest.csv');conf=rows(R/'data/confirmation_manifest.csv')
pred=np.load(R/'results/validated_predictions.npz');source=np.load(R/'results/source_predictions.npz')
excluded=set(json.loads((R/'data/excluded_confirmation_images.json').read_text())['all_screened_candidates'])
old=rows(R/'results/validated_paired_intervals.csv');res=[];crosschecks=0
for fold,m in enumerate(museums):
 rr=[r for r in conf if r['museum']==m];y=np.array([classes.index(r['medium']) for r in rr])
 for policy in ['original','exclude_all_candidates']:
  keep=np.ones(len(y),bool) if policy=='original' else np.array([r['image_file'] not in excluded for r in rr])
  rng=np.random.default_rng(20261024+fold);weights=np.zeros((5000,len(y)))
  for c in range(17):
   ix=np.flatnonzero((y==c)&keep);weights[:,ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)),size=5000)/(17*len(ix))
  for enc in ['convnext','dinov2']:
   for method in ['append','balanced','easyadapt']:
    correct=np.mean([pred[f'head_{enc}_{fold}_{seed}_5_{method}']==y for seed in range(10)],axis=0)
    for cmp in ['target_only','prototype']:
     other=np.mean([pred[f'head_{enc}_{fold}_{seed}_5_{cmp}']==y for seed in range(10)],axis=0)
     diff=correct-other;gain=100*np.mean([diff[(y==c)&keep].mean() for c in range(17)])
     lo,hi=100*np.quantile(weights@diff,[.025,.975])
     row=dict(encoder=enc,museum=m,policy=policy,method=method,comparison=cmp,gain_pp=float(gain),lower_pp=float(lo),upper_pp=float(hi),bootstrap_replicates=5000)
     res.append(row)
     if method=='easyadapt':
      o=next(v for v in old if v['policy']==policy and v['encoder']==enc and v['museum']==m and v['comparison']=='tuned_easyadapt_minus_'+cmp)
      for val,k in [(gain,'gain_pp'),(lo,'lower_pp'),(hi,'upper_pp')]:assert np.isclose(val,float(o[k]),atol=1e-10,rtol=0)
      crosschecks+=1
with (O/'all_joint_source_reuse_intervals.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(res[0]));w.writeheader();w.writerows(res)
print('Intervals',len(res),'EasyAdapt crosschecks',crosschecks,'minimum lower pp',min(r['lower_pp'] for r in res),flush=True)

