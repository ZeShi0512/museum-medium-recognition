"""Re-extract frozen features from the pinned MAMe small archive.

This optional command reads locally supplied upstream images, weights, and
DINOv2 source code. It never downloads files or installs packages. Use the
original runtime versions listed in protocols/original_runtime.json.
"""
from pathlib import Path
import argparse,csv,hashlib,json,sys,zipfile
import numpy as np
from PIL import Image
import torch

R=Path(__file__).resolve().parents[1]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while block:=f.read(1024*1024):h.update(block)
    return h.hexdigest()
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archive',type=Path,required=True)
    ap.add_argument('--weights',type=Path,required=True)
    ap.add_argument('--encoder',choices=['convnext','dinov2'],required=True)
    ap.add_argument('--dinov2-code-dir',type=Path)
    ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--threads',type=int,default=8)
    args=ap.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    source=json.loads((R/'protocols/data_source.json').read_text())
    protocol=json.loads((R/'protocols/historical_development.json').read_text())
    if sha(args.archive)!=source['archive_sha256']:raise ValueError('image archive SHA256 differs')
    if sha(args.weights)!=protocol['models'][args.encoder]['weight_sha256']:raise ValueError('model weight SHA256 differs')
    torch.set_num_threads(args.threads);torch.set_num_interop_threads(1)
    torch.manual_seed(20261024);torch.use_deterministic_algorithms(True)
    if args.encoder=='convnext':
        from torchvision.models import convnext_tiny
        model=convnext_tiny(weights=None).eval()
        def encode(x):return model.classifier[1](model.classifier[0](model.avgpool(model.features(x))))
    else:
        if args.dinov2_code_dir is None:ap.error('--dinov2-code-dir is required for dinov2')
        sys.path.insert(0,str(args.dinov2_code_dir.resolve()))
        from dinov2.hub.backbones import dinov2_vits14
        model=dinov2_vits14(pretrained=False).eval()
        def encode(x):return model(x)
    model.load_state_dict(torch.load(args.weights,map_location='cpu',weights_only=True),strict=True)
    receipt={'encoder':args.encoder,'image_archive_sha256':source['archive_sha256'],'weight_sha256':protocol['models'][args.encoder]['weight_sha256'],'outputs':[]}
    with zipfile.ZipFile(args.archive) as archive:
        members={}
        for entry in archive.infolist():
            if entry.is_dir():continue
            name=Path(entry.filename).name
            if name in members:raise ValueError('duplicate archive basename: '+name)
            members[name]=entry.filename
        def tensor(row):
            with archive.open(members[row['image_file']]) as f:
                im=Image.open(f).convert('RGB')
            if im.size!=(256,256):raise ValueError('unexpected image dimensions')
            a=np.asarray(im.crop((16,16,240,240)),dtype=np.float32)/255
            a=(a-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)
            return torch.from_numpy(a.transpose(2,0,1).copy())
        for role in ['development','confirmation']:
            rr=rows(R/f'data/{role}_manifest.csv');features=[]
            for i in range(0,len(rr),16):
                with torch.inference_mode():
                    z=torch.nn.functional.normalize(encode(torch.stack([tensor(r) for r in rr[i:i+16]])),dim=-1).numpy()
                if not np.isfinite(z).all():raise ValueError('nonfinite features')
                features.extend(z);print(args.encoder,role,len(features),'/',len(rr),flush=True)
            path=args.output_dir/f'{role}_{args.encoder}.npz'
            np.savez_compressed(path,ids=np.array([r['image_file'] for r in rr]),features=np.array(features,dtype=np.float32))
            receipt['outputs'].append({'path':path.name,'rows':len(rr),'sha256':sha(path)})
    (args.output_dir/f'extraction_receipt_{args.encoder}.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
